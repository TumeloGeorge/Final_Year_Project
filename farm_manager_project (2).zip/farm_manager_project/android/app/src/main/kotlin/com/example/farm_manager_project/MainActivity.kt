package com.example.farm_manager_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
