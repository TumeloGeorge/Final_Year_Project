// lib/csv_importer.dart
import 'package:flutter/services.dart';
import 'package:csv/csv.dart';
import 'database_helper.dart';

class CsvImporter {
  final DatabaseHelper dbHelper;

  CsvImporter(this.dbHelper);

  Future<void> importCropData() async {
    final rawData = await rootBundle.loadString('assets/crops.csv');
    List<List<dynamic>> csvData = const CsvToListConverter().convert(rawData);

    // Skip header row
    for (var row in csvData.skip(1)) {
      final cropName = row[0].toString();
      final lifespan = int.parse(row[1].toString());
      
      // Insert crop (start date will be set later by user)
      final cropId = await dbHelper.insertCrop(cropName, lifespan, DateTime.now());

      // Import tasks starting from column 2
      for (int i = 2; i < row.length; i++) {
        final taskName = row[i].toString();
        final taskDay = i - 2; // Days after planting
        await dbHelper.insertTask(cropId, taskName, taskDay);
      }
    }
  }
}