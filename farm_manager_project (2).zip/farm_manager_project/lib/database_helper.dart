// lib/database_helper.dart
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static const _databaseName = "farm_management.db";
  static const _databaseVersion = 2;

  static const cropsTable = 'crops';
  static const tasksTable = 'tasks';

  // Columns for crops
  static const columnId = 'id';
  static const columnCropName = 'crop_name';
  static const columnLifespan = 'lifespan_days';
  static const columnStartDate = 'start_date';

  // Columns for tasks
  static const columnTaskName = 'task_name';
  static const columnTaskDay = 'task_day';
  static const columnScheduledDate = 'scheduled_date';
  static const columnStatus = 'status';

  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), _databaseName);
    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
    );
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $cropsTable (
        $columnId INTEGER PRIMARY KEY AUTOINCREMENT,
        $columnCropName TEXT NOT NULL,
        $columnLifespan INTEGER NOT NULL,
        $columnStartDate TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE $tasksTable (
        $columnId INTEGER PRIMARY KEY AUTOINCREMENT,
        crop_id INTEGER NOT NULL,
        $columnTaskName TEXT NOT NULL,
        $columnTaskDay INTEGER NOT NULL,
        $columnScheduledDate TEXT NOT NULL,
        $columnStatus TEXT DEFAULT 'pending',
        FOREIGN KEY (crop_id) REFERENCES $cropsTable ($columnId)
      )
    ''');
  }

  // Crop operations
  Future<int> insertCrop(String name, int lifespan, DateTime startDate) async {
    final db = await database;
    return await db.insert(cropsTable, {
      columnCropName: name,
      columnLifespan: lifespan,
      columnStartDate: startDate.toIso8601String(),
    });
  }

  Future<List<Map<String, dynamic>>> getCrops() async {
    final db = await database;
    return await db.query(cropsTable);
  }

  // Task operations
  Future<int> insertTask(int cropId, String taskName, int taskDay) async {
    final db = await database;
    return await db.insert(tasksTable, {
      'crop_id': cropId,
      columnTaskName: taskName,
      columnTaskDay: taskDay,
      columnScheduledDate: '', // Will be calculated later
    });
  }

  Future<void> updateTaskDate(int taskId, DateTime date) async {
    final db = await database;
    await db.update(
      tasksTable,
      {columnScheduledDate: date.toIso8601String()},
      where: '$columnId = ?',
      whereArgs: [taskId],
    );
  }

  Future<List<Map<String, dynamic>>> getTasks(int cropId) async {
    final db = await database;
    return await db.query(
      tasksTable,
      where: 'crop_id = ?',
      whereArgs: [cropId],
    );
  }
}