-- Created to realise inheritance in the database since MySQL does not support inheritance an the two users perform the same action ()
-- post on forums, as such to avoid redundancy, we create a parent table called Users and two child tables Farmer and Agronomist
-- The schema.sql file contains the SQL code to create the tables in the database
CREATE TABLE Users (
    user_id   INT PRIMARY KEY,
    user_name VARCHAR(50) NOT NULL,
    email     VARCHAR(100) NOT NULL
);


CREATE TABLE Farmer (
    farmer_id INT PRIMARY KEY,
    farm_number_of_farms INT,
    FOREIGN KEY (farmer_id) REFERENCES Users(user_id)
);


CREATE TABLE Agronomist (
    agronomist_id INT PRIMARY KEY,
    FOREIGN KEY (agronomist_id) REFERENCES Users(user_id)
);


CREATE TABLE Forum (
    forum_id INT PRIMARY KEY,
    location VARCHAR(100) NOT NULL
);

CREATE TABLE Posts (
    post_id           INT PRIMARY KEY,
    user_id           INT NOT NULL,
    forum_id          INT NOT NULL,
    content           TEXT NOT NULL,
    post_time         DATE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reply_to_post_id  INT, --this is the post_id of the post that this post is replying to. It is null if the post is not a reply
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    FOREIGN KEY (forum_id) REFERENCES Forum(forum_id),
    FOREIGN KEY (reply_to_post_id) REFERENCES Posts(post_id)
);


CREATE TABLE Farm (
    farm_id   INT PRIMARY KEY,
    farmer_id INT NOT NULL,
    location  VARCHAR(100) NOT NULL,
    size      INT,
    FOREIGN KEY (farmer_id) REFERENCES Farmer(farmer_id)
);

CREATE TABLE FinancialTransactions (
    transaction_id   INT PRIMARY KEY,
    farm_id          INT NOT NULL,
    amount           DECIMAL(10,2) NOT NULL,
    transaction_time DATE NOT NULL DEFAULT CURRENT_TIMESTAMP, --current time stamp is the time captured when a post is made
    description      TEXT,
    FOREIGN KEY (farm_id) REFERENCES Farm(farm_id)
);


CREATE TABLE Goal (
    goal_id    INT PRIMARY KEY,
    farmer_id  INT NOT NULL,
    name       VARCHAR(100) NOT NULL,
    description TEXT,
    is_in_progress BOOLEAN,
    FOREIGN KEY (farmer_id) REFERENCES Farmer(farmer_id)
);

CREATE TABLE Task (
    task_id    INT PRIMARY KEY,
    goal_id    INT NOT NULL,
    name       VARCHAR(100) NOT NULL,
    description TEXT,
    due_date   DATE,
    is_complete BOOLEAN,
    FOREIGN KEY (goal_id) REFERENCES Goal(goal_id)
);


CREATE TABLE Milestone (
    milestone_id INT PRIMARY KEY,
    goal_id      INT NOT NULL,
    name         VARCHAR(100) NOT NULL,
    due_date     DATE,
    status       VARCHAR(50),
    FOREIGN KEY (goal_id) REFERENCES Goal(goal_id)
);
