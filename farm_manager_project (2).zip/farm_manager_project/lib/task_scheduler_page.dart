// lib/task_scheduler_page.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import 'database_helper.dart';

class TaskSchedulerPage extends StatefulWidget {
  const TaskSchedulerPage({super.key});

  @override
  _TaskSchedulerPageState createState() => _TaskSchedulerPageState();
}

class _TaskSchedulerPageState extends State<TaskSchedulerPage> {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;
  final _cropController = TextEditingController();
  final _lifespanController = TextEditingController();
  DateTime? _startDate;
  List<Map<String, dynamic>> _crops = [];
  final Map<DateTime, List<String>> _events = {};

  @override
  void initState() {
    super.initState();
    _loadCrops();
  }

  Future<void> _loadCrops() async {
    _crops = await _dbHelper.getCrops();
    setState(() {});
  }

  Future<void> _addCrop() async {
    if (_cropController.text.isEmpty || 
        _lifespanController.text.isEmpty || 
        _startDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Fill all fields!')),
      );
      return;
    }

    try {
      final cropId = await _dbHelper.insertCrop(
        _cropController.text,
        int.parse(_lifespanController.text),
        _startDate!,
      );

      // Schedule tasks
      final tasks = await _dbHelper.getTasks(cropId);
      for (var task in tasks) {
        final scheduledDate = _startDate!.add(Duration(days: task['task_day']));
        await _dbHelper.updateTaskDate(task['id'], scheduledDate);
      }

      _cropController.clear();
      _lifespanController.clear();
      setState(() => _startDate = null);
      await _loadCrops();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  List<String> _getTasksForDay(DateTime day) {
    return _events[day] ?? [];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Crop Scheduler')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Crop Input Form
            TextField(
              controller: _cropController,
              decoration: const InputDecoration(labelText: 'Crop Name'),
            ),
            TextField(
              controller: _lifespanController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Lifespan (days)'),
            ),
            ListTile(
              title: Text(_startDate == null 
                  ? 'Select Start Date' 
                  : 'Start Date: ${DateFormat.yMd().format(_startDate!)}'),
              trailing: const Icon(Icons.calendar_today),
              onTap: () async {
                final date = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(2000),
                  lastDate: DateTime(2100),
                );
                if (date != null) setState(() => _startDate = date);
              },
            ),
            ElevatedButton(
              onPressed: _addCrop,
              child: const Text('Add Crop Schedule'),
            ),

            // Crop List
            Expanded(
              child: ListView.builder(
                itemCount: _crops.length,
                itemBuilder: (context, index) {
                  final crop = _crops[index];
                  return ListTile(
                    title: Text(crop['crop_name']),
                    subtitle: Text('Lifespan: ${crop['lifespan_days']} days'),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CropCalendarPage(cropId: crop['id']),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CropCalendarPage extends StatelessWidget {
  final int cropId;

  const CropCalendarPage({super.key, required this.cropId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Crop Calendar')),
      body: FutureBuilder(
        future: DatabaseHelper.instance.getTasks(cropId),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          
          final tasks = snapshot.data!;
          final events = <DateTime, List<String>>{};
          for (var task in tasks) {
            final date = DateTime.parse(task['scheduled_date']);
            events[date] = [...events[date] ?? [], task['task_name']];
          }

          return TableCalendar(
            focusedDay: DateTime.now(),
            firstDay: DateTime(2000),
            lastDay: DateTime(2100),
            eventLoader: (day) => events[day] ?? [],
            calendarStyle: const CalendarStyle(
              markerDecoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle),
            ),
          );
        },
      ),
    );
  }
}